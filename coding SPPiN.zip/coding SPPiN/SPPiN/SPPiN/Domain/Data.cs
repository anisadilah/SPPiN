﻿using SPPiN.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SPPiN.Domain
{
    public class Data
    {
        public IEnumerable<Navbar> navbarItems()
        {
            var menu = new List<Navbar>();
            menu.Add(new Navbar { Id = 1, nameOption = "Laman Utama", controller = "Home", action = "Index", imageClass = "fa fa-dashboard fa-fw", status = true, isParent = false, parentId = 0 });
            menu.Add(new Navbar { Id = 2, nameOption = "Senarai Permohonan", imageClass = "fa fa-edit fa-fw", status = true, isParent = true, parentId = 0 });
            menu.Add(new Navbar { Id = 3, nameOption = "Permohonan Baru", controller = "Home", status = true, isParent = false, parentId = 2 });
            menu.Add(new Navbar { Id = 4, nameOption = "Permohonan Rayuan", controller = "Home", status = true, isParent = false, parentId = 2 });
            menu.Add(new Navbar { Id = 5, nameOption = "Laporan Bayaran", imageClass = "fa fa-table", status = true, isParent = true, parentId = 0 });
            menu.Add(new Navbar { Id = 6, nameOption = "Senarai Bayaran", controller = "Home", status = true, isParent = false, parentId = 5 });
            menu.Add(new Navbar { Id = 7, nameOption = "Lawatan Tapak", imageClass = "fa fa-table", status = true, isParent = true, parentId = 0 });
            menu.Add(new Navbar { Id = 8, nameOption = "Senarai Lawatan Tapak", controller = "Home", status = true, isParent = false, parentId = 7 });
            return menu.ToList();
        }
    }
}